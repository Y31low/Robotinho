package Game.model;

public enum Direzione {
    North,
    West,
    South,
    East;
}
