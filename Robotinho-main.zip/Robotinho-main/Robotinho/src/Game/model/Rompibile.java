package Game.model;

public interface Rompibile{

    public void perdita();

    public void espandiPerdita();

    public void interrompiPerdita();
}
