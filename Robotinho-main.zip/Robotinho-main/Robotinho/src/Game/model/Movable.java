package Game.model;

public interface Movable {
    public void Avanza(Direzione direzione);

}
